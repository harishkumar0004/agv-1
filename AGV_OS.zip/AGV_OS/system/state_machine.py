from enum import Enum, auto


class AGVState(Enum):
    OFF = auto()
    BOOTING = auto()
    INITIALIZING = auto()
    SELF_TEST = auto()
    READY = auto()
    RUNNING = auto()
    PAUSED = auto()
    FAULT = auto()
    EMERGENCY_STOP = auto()
    SHUTDOWN = auto()