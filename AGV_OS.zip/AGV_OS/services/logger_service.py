from core.base_service import BaseService

from system.logger import AGVLogger


class LoggerService(BaseService):

    def __init__(self):

        super().__init__("Logger")

        self.logger = AGVLogger()

    def start(self):

        self.running = True

        self.logger.info("Logger Started")

    def stop(self):

        self.running = False

        self.logger.info("Logger Stopped")