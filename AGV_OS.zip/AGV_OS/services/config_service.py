from core.base_service import BaseService

from system.config_manager import ConfigManager


class ConfigService(BaseService):

    def __init__(self):

        super().__init__("Config")

        self.config = ConfigManager()

    def start(self):

        self.config.load()

        self.running = True

    def stop(self):

        self.running = False