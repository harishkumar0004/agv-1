from AGV_OS.core.agv_system import AGVSystem

def main():
    agv = AGVSystem()
    agv.start()

if __name__ == "__main__":
    main()

