from pathlib import Path
import logging
from datetime import datetime

# Every Subsystem will use this logger instead of print()

class AGVLogger:
    def __init__(self):
        Path("logs").mkdir(exist_ok=True)

        filename = datetime.now().strftime("logs/%Y%m%d.log")

        logging.basicConfig(
            filename=filename,
            level=logging.INFO,
            format="%(asctime)s %(message)s"
        )
    def info(self, message):
        logging.info(message)
        print(message)