import time

class BootManager:
    def start(self):
        self.show_logo()
        self.load_configuration()
        self.initialize_modules()
        self.perform_self_test()
        self.finish()

    def show_logo(self):
        print("Loading AGV OS...")
        time.sleep(1)

    def load_configuration(self):
        print("Loading configuration...")
        time.sleep(0.5)

    def initialize_modules(self):
        print("Initializing modules...")
        time.sleep(0.5)

    def perform_self_test(self):
        print("Running self test...")
        time.sleep(0.5)

    def finish(self):
        print("Boot Completed")

     
        