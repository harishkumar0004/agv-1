class HealthMonitor:
    def __init__(self):
        self.components = {}
    
    def register(self, name):
        self.components[name] = False
    
    def healthy(self):
        return all(self.components.values())
    
    