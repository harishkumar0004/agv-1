import json
from pathlib import Path

class ConfigManager:
    def __init__(self):
        self.config = {}
        self.robot_info = {}

    def load(self):
        self.config = self._read_json("config/config.json")
        self.robot_info = self._read_json("config/robot_info.json")

    def _read_json(self, filename):
        path = Path(filename)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {filename}")
        
        with open(path, "r") as file:
            return json.load(file)
        
    def get(self, *keys):
        data = self.config
        
        for key in keys:
            data = data[key]
        
        return data
    
    def get_robot_info(self, key):
        return self.robot_info[key]