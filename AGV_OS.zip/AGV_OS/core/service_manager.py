class ServiceManager:

    def __init__(self):

        self.services = {}

    def register(self, service):

        self.services[service.name] = service

    def start_service(self, name):
        if name in self.services:
            self.services[name].start()

    def stop_service(self, name):
        if name in self.services:
            self.services[name].stop()

    def start_all(self):

        for service in self.services.values():

            service.start()

    def stop_all(self):

        for service in reversed(list(self.services.values())):

            service.stop()

    def status(self):
        return {
            name:service.is_running()
            for name, service in self.services.items()
        }