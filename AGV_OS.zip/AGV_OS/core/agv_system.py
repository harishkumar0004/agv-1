from core.service_manager import ServiceManager

from services.logger_service import LoggerService
from services.config_service import ConfigService

from managers.boot_manager import BootManager
from system.state_machine import AGVState

class AGVSystem:

    def __init__(self):

        self.state = AGVState.BOOTING

        self.service_manager = ServiceManager()

        self.boot = BootManager(self.service_manager)

        self.register_services()

    def register_services(self):

        self.service_manager.register(LoggerService())

        self.service_manager.register(ConfigService())

    def start(self):

        self.boot.start()

        self.state = AGVState.READY

        print("AGV State -> READY")