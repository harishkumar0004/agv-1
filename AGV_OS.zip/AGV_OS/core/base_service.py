from abc import ABC, abstractmethod


class BaseService(ABC):

    def __init__(self, name):

        self.name = name

        self.running = False

    @abstractmethod
    def start(self):
        pass

    @abstractmethod
    def stop(self):
        pass

    def is_running(self):

        return self.running

    def info(self):

        return {

            "name": self.name,

            "running": self.running
        }